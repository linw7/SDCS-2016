m0 = imread('37.png');
imshow(m0,[]);
title('Original Image');
A = [200,500];
m1=zeros(A);
[height weight]=size(m0);
for i=0:A(1)-1
    for j=0:A(2)-1
        if i ~=A(1)-1 && j~=A(2)-1
            mi1 = [height/A(1)*i-floor(height/A(1)*i)]*m0(floor(height/A(1)*i)+2,floor(weight/A(2)*j)+1)+(1- [height/A(1)*i-floor(height/A(1)*i)])*m0(floor(height/A(1)*i+1),floor(weight/A(2)*j+1));
            mi2 = [height/A(1)*i-floor(height/A(1)*i)]*m0(floor(height/A(1)*i)+2,floor(weight/A(2)*j)+2)+(1- [height/A(1)*i-floor(height/A(1)*i)])*m0(floor(height/A(1)*i)+2,floor(weight/A(2)*j)+1);
            m1(i+1,j+1) = [weight/A(2)*j-floor(weight/A(2)*j)]*mi2+(1- [weight/A(2)*j-floor(weight/A(2)*j)])*mi1;
        else
            m1(i+1,j+1) = m0(floor(height/A(1)*(i)+1),floor(weight/A(2)*(j)+1));
        end
    end
end
%m1 = imresize(input_image,[200,500],'bilinear');
figure;
imshow(m1,[]);