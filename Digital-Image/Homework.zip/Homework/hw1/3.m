m0 = imread('37.png');
imshow(m0,[]);
title('Original Image');
[height weight]=size(m0);
m1 = m0;
m=8;
for i = 1:height
    for j = 1:weight
        m1(i,j) = floor(double(m0(i,j))/m)*(m-1);
    end
end
figure;
imshow(m1,[]);