input_img = imread ('35.png');
[height, weight] = size(input_img);
output_img = input_img;
m=11; %mΪƽ����Ĵ�С
avaf = 1/(m*m)*ones(m,m);
for i = 1 + (m-1)/2 : height - (m-1)/2
    for j = 1 + (m-1)/2 : weight - (m-1)/2
        output_img(i,j) = 0;
        for s = -(m-1)/2 : (m-1)/2
            for t = -(m-1)/2 : (m-1)/2
                output_img(i,j) = output_img(i,j) + input_img(i-s,j-t) * avaf(s+(m-1)/2+1,t+(m-1)/2+1);
            end
        end
    end
end
figure;
subplot(2,2,1); 
imshow(input_img)
title('ԭͼ');  
subplot(2,2,2);  
imshow(output_img);  
title('ģ��ͼ��'); 