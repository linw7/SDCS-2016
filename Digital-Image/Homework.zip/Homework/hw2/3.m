input_img = imread ('35.png');
[height, weight] = size(input_img);
output_img = zeros(height, weight);
m=3; %mΪƽ����Ĵ�С
avaf = 1/(m*m)*ones(m,m);%���Ը���Ϊ�����˲���

for i = 1 + (m-1)/2 : height - (m-1)/2%�˲�����
    for j = 1 + (m-1)/2 : weight - (m-1)/2
        for s = -(m-1)/2 :1: (m-1)/2
            for t = -(m-1)/2 :1: (m-1)/2
                output_img(i,j) = output_img(i,j) + double(input_img(i-s,j-t)) * avaf(s+(m-1)/2+1,t+(m-1)/2+1);
            end
        end
          if output_img(i,j) < 0
                    output_img(i,j) = 0;
          end
         
    end
end
 output_img=double(input_img) + 0.3*output_img;
figure;
subplot(2,2,1); 
imshow(input_img)
title('ԭͼ');  
subplot(2,2,2);  
imshow(output_img,[]);  
title('ģ��'); 