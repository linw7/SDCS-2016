clc;
close all;
clear all;

input_img = imread('35.png');
input = double(input_img);
[height weight]=size(input_img);
f = sqrt(-1); %����������ʾ
A = zeros(height,height);
B = zeros(weight,weight);
C = zeros(height,height);
D = zeros(weight,weight);
for i = 1:height %���Ļ�ͼƬ
    for j = 1:weight
        input(i,j) = input(i,j)*(-1)^(i+j);
    end
end
for i = 1:height
    for j = 1:height
        A(i,j) = 1/sqrt(height)*exp(-f*2*pi*(i-1)*(j-1)/height);
        C(i,j) = 1/sqrt(height)*exp(f*2*pi*(i-1)*(j-1)/height);
    end
end
for i = 1:weight
    for j = 1:weight
        B(i,j) = 1/sqrt(weight)*exp(-f*2*pi*(i-1)*(j-1)/weight);
        D(i,j) = 1/sqrt(weight)*exp(f*2*pi*(i-1)*(j-1)/weight);
    end
end
output =  A*input*B;
%Ƶ������ӻ�����
RR = real(output);%ȡʵ��
II = imag(output);%ȡ�鲿
output_img = sqrt(RR.^2+II.^2); 
output_img = (output_img-min(min(output_img)))/(max(max(output_img))-min(min(output_img)))*255;%��һ������


org = C*(output)*D;
org = real(org);%ȡʵ��

for i = 1:height %ȥ���Ļ�
    for j = 1:weight
        org(i,j) = org(i,j)*(-1)^(i+j);
    end
end

figure;
subplot(1,3,1);
imshow(input_img); 
title('ԭͼ��');
subplot(1,3,2);
imshow(output_img);
title('Ƶ��ͼ');
subplot(1,3,3);
imshow(org,[]);
title('��ԭ');
