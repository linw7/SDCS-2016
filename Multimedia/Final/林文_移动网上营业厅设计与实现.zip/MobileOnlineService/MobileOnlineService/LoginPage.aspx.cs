﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Clear();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int numLength = login_name.Text.Trim().Length;

            string login_num = login_name.Text.Trim();
            string pass_num = login_pass.Text.Trim();
            Session["loginpass"] = login_pass.Text.Trim();
            Session["loginname"] = login_name.Text.Trim();
            //string selectString;
            //string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;

            if (numLength == 11)
            {
                //selectString = "SELECT id  FROM [user] WHERE mobile_num=@mobile_num and login_pass=@login_pass";
                //using (SqlConnection connection = new SqlConnection(connectionString))
                //{
                //    connection.Open();
                //    SqlCommand command = new SqlCommand(selectString, connection);
                //    command.Parameters.AddWithValue("@mobile_num", login_name.Text);
                //    command.Parameters.AddWithValue("@login_pass",login_pass.Text);
                //    SqlDataReader reader = command.ExecuteReader();
                //    if (reader.Read())
                //    {
                //        Session["mobile_num"] = login_name.Text.Trim();
                //        Session["user_id"] = reader["id"].ToString();
                //        Response.Redirect("~/user/search.aspx");

                //    }
                //    else
                //    {
                //        Response.Write("<Script Language='JavaScript'>window.alert('账户或密码错误！请注意大小写！');</script>");
                //    }

                //}
                using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
                {
                    var items = from item in context.User where item.mobile_num == login_num & item.login_pass == pass_num select item;
                    if (items.Count() > 0)
                    {
                        Session["mobile_num"] = login_num;
                        Session["user_id"] = items.Single().Id;
                        Session["cn"] = items.Single().card_num;
                        Session["pwd"] = items.Single().pay_pass;

                        Response.Redirect("~/user/plan.aspx");
                    }
                    else
                    {
                        Response.Write("<Script Language='JavaScript'>window.alert('账户或密码错误！请注意大小写！');</script>");
                    }
                }
            }
            else if (numLength == 9)
            {
                //selectString = "SELECT id FROM [staff] WHERE staff_num=@staff_num and login_pass=@login_pass";
                //using (SqlConnection connection = new SqlConnection(connectionString))
                //{
                //    connection.Open();
                //    SqlCommand command = new SqlCommand(selectString, connection);
                //    command.Parameters.AddWithValue("@staff_num", login_name.Text);
                //    command.Parameters.AddWithValue("@login_pass", login_pass.Text);
                //    SqlDataReader reader = command.ExecuteReader();
                //    if(reader.Read())
                //    {
                //        Session["staff_num"] = login_name.Text;
                //        Response.Redirect("~/staff/new.aspx");
                //    }
                //    else
                //    {
                //        Response.Write("<Script Language='JavaScript'>window.alert('账户或密码错误！请注意大小写！');</script>");
                //    }

                //}
                using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
                {
                    var items = from item in context.Staff where item.staff_num == login_num & item.login_pass == pass_num select item;
                    if (items.Count() > 0)
                    {
                        Session["staff_num"] = login_num;
                        
                        Response.Redirect("~/staff/new.aspx");
                    }
                    else
                    {
                        Response.Write("<Script Language='JavaScript'>window.alert('账户或密码错误！请注意大小写！');</script>");
                    }
                }
            }
            else if (numLength == 7)
            {
                //    selectString = "SELECT id FROM [administrator] WHERE admin_num=@admin_num and login_pass=@login_pass";
                //    using (SqlConnection connection = new SqlConnection(connectionString))
                //    {
                //        connection.Open();
                //        SqlCommand command = new SqlCommand(selectString, connection);
                //        command.Parameters.AddWithValue("@admin_num", login_name.Text);
                //        command.Parameters.AddWithValue("@login_pass", login_pass.Text);
                //        SqlDataReader reader = command.ExecuteReader();
                //        if(reader.Read())
                //        {
                //            Session["admin_num"] = login_name.Text;
                //            Response.Redirect("~/administrator/plan.aspx");

                //        }
                //        else
                //        {
                //            Response.Write("<Script Language='JavaScript'>window.alert('账户或密码错误！请注意大小写！');</script>");
                //        }

                //    }
                //}
                //else
                //{
                //    Response.Write("<Script Language='JavaScript'>window.alert('请输入有效账号！');</script>");
                //}
                using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
                {
                    var items = from item in context.Administrator where item.admin_num == login_num & item.login_pass == pass_num select item;
                    if (items.Count() > 0)
                    {
                        Session["admin_num"] = login_num;
                        Response.Redirect("~/administrator/plan_detail.aspx");
                    }
                    else
                    {
                        Response.Write("<Script Language='JavaScript'>window.alert('账户或密码错误！请注意大小写！');</script>");
                    }
                }

            }
        }
    }
}