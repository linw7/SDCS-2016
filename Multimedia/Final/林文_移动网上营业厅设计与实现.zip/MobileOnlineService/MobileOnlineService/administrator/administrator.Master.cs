﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.administrator
{
    public partial class administrator : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin_num"] != null)
            {
                login_name.Text = "欢迎 管理员：" + Session["admin_num"].ToString();
            }
            else
            {
                login_name.Text = "欢迎 匿名管理员 ";
            }
        }
    }
}