﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace MobileOnlineService.administrator
{
    public partial class card_add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
            string sql = string.Format("insert into [table](card_num,passwd,price) values('{0}','{1}',{2})", Convert.ToInt32(TextBox1.Text.Trim()), TextBox2.Text.Trim(), Convert.ToInt32(DropDownList1.SelectedValue));

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {
                    Response.Write("<script>alert('添加成功')</script>");
                }
            }
        }
    }
}