﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace MobileOnlineService.administrator
{
    public partial class card_detail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
                //string sql = string.Format("select * from [table]");

                //using (SqlConnection conn = new SqlConnection(connectionString))
                //{
                //    conn.Open();
                //    SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                //    DataTable dt = new DataTable();
                //    sda.Fill(dt);
                //    GridView1.DataSource = dt;
                //    GridView1.DataBind();
                //    for (int i = 0; i < GridView1.Rows.Count; i++)
                //    {
                //        Label lb = this.GridView1.Rows[i].FindControl("Label1") as Label;
                //        lb.Text = Convert.ToInt32(lb.Text) == 1 ? "可用" : "不可用";
                //    }
                //}


            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}