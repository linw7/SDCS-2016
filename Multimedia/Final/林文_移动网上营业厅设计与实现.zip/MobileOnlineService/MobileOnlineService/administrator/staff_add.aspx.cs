﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.administrator
{
    public partial class staff_add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
        //    string insertString = "INSERT INTO [staff](staff_num,workplace,login_pass,position)values(@staff_num,@workplace,@login_pass,@position)";
        //    string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
        //    try
        //    {
        //        using (SqlConnection connection = new SqlConnection(connectionString))
        //        {
        //            connection.Open();
        //            SqlCommand command = new SqlCommand(insertString, connection);
        //            command.Parameters.Clear();
        //            command.Parameters.AddWithValue("@staff_num", staff_num.Text);
        //            command.Parameters.AddWithValue("@login_pass", login_pass.Text);
        //            command.Parameters.AddWithValue("@workplace", location.Text);
        //            command.Parameters.AddWithValue("@position", position.Text);
                    
        //            int result = command.ExecuteNonQuery();
        //            if (result > 0)
        //            {
        //                Response.Write("<Script Language='JavaScript'>window.alert('创建成功！');</script>");
        //                Response.Redirect("~/administrator/staff_add.aspx");
        //            }

        //        }
        //    }
        //    catch (SqlException ee)
        //    {
        //        if (ee.Number == 2627)//主键重复，重复插入错误
        //        {
        //            Response.Write("<Script Language='JavaScript'>window.alert('账户已存在，创建失败！');</script>");
        //            return;
        //        }
        //        throw;
        //    }
        //    catch
        //    { Response.Write("<Script Language='JavaScript'>window.alert('创建失败！！');</script>"); }

            try
            {
                using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
                {
                    Staff s = new Staff();
                    s.staff_num = staff_num.Text.Trim();
                    s.login_pass = login_pass.Text.Trim();
                    s.position = position.Text.Trim();
                    s.workplace = location.Text.Trim();
                    context.Staff.Add(s);
                    context.SaveChanges();
                    Response.Write("<Script Language='JavaScript'>window.alert('创建成功！');</script>");
                    Response.Redirect("~/administrator/staff_add.aspx");
                }
            }
            catch(Exception){
                Response.Write("<Script Language='JavaScript'>window.alert('创建失败！！');</script>");
            }
                
            

        }
    }
}