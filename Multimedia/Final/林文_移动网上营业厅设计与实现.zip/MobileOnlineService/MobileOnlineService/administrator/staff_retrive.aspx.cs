﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.administrator
{
    public partial class staff_retrive : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            //string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
            //string selectString = "SELECT id  FROM [staff] WHERE staff_num=@staff_num";
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    connection.Open();
            //    SqlCommand command = new SqlCommand(selectString, connection);
            //    command.Parameters.AddWithValue("@staff_num", staff_num.Text);
            //    SqlDataReader reader = command.ExecuteReader();
            //    if (reader.Read())
            //    {
            //        Session["r_staff_num"] = staff_num.Text;
            //        Response.Redirect("~/administrator/staff_detail.aspx");
            //    }

                
            //    else{
            //        Response.Write("<Script Language='JavaScript'>window.alert('用户不存在');</script>");
            //    }
                
            //}

            using(MobileOnlineServiceEntities context = new MobileOnlineServiceEntities()){
                var items = from item in context.Staff where item.staff_num == staff_num.Text.Trim() select item;
                if (items.Count() > 0)
                {
                    Session["r_staff_num"] = staff_num.Text.Trim();
                    Response.Redirect("~/administrator/staff_detail.aspx");
                }
                else
                {
                    Response.Write("<Script Language='JavaScript'>window.alert('用户不存在');</script>");
                }
            }
        }
    }
}