﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.staff
{
    public partial class _new : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
        //    string insertString = "INSERT INTO [user](mobile_num,login_pass,num_location,card_num,pay_pass,credit,balance,email)values(@mobile_num,@login_pass,@num_location,@card_num,@pay_pass,@credit,@balance,@email)";
        //    string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
        //    try
        //    {
        //        using (SqlConnection connection = new SqlConnection(connectionString))
        //        {
        //            connection.Open();
        //            SqlCommand command = new SqlCommand(insertString, connection);
        //            command.Parameters.Clear();
        //            command.Parameters.AddWithValue("@mobile_num", mobile_num.Text);
        //            command.Parameters.AddWithValue("@login_pass", login_pass.Text);
        //            command.Parameters.AddWithValue("@num_location", location.Text);
        //            command.Parameters.AddWithValue("@card_num", card_id.Text);
        //            command.Parameters.AddWithValue("@pay_pass", pay_num.Text);
        //            command.Parameters.AddWithValue("@credit", credit.Text);
        //            command.Parameters.AddWithValue("@balance", balance.Text);
        //            command.Parameters.AddWithValue("@email", email.Text);
                    
        //            int result = command.ExecuteNonQuery();
        //            if (result > 0)
        //            {
        //                Response.Write("<Script Language='JavaScript'>window.alert('创建成功！');</script>");
        //                Response.Redirect("~/staff/new.aspx");
        //            }

        //        }
        //    }
        //    catch (SqlException ee)
        //    {
        //        if (ee.Number == 2627)//主键重复，重复插入错误
        //        {
        //            Response.Write("<Script Language='JavaScript'>window.alert('账户已存在，创建失败！');</script>");
        //            return;
        //        }
        //        throw;
        //    }
        //    catch
        //    { Response.Write("<Script Language='JavaScript'>window.alert('创建失败！！');</script>"); }

            try
            {
                using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
                {
                    User user = new User();
                    user.mobile_num = mobile_num.Text.Trim();
                    user.login_pass = login_pass.Text.Trim();
                    user.num_location = location.Text.Trim();
                    user.card_num = card_id.Text.Trim();
                    user.pay_pass = pay_num.Text.Trim();
                    user.balance = Convert.ToDecimal(balance.Text.Trim());
                    user.credit = Convert.ToInt32(credit.Text.Trim());
                    user.email = email.Text.Trim();
                    context.User.Add(user);
                    context.SaveChanges();
                    Response.Write("<Script Language='JavaScript'>window.alert('创建成功！');</script>");
                    Response.Redirect("~/staff/new.aspx");
                }
            }
            catch (Exception)
            {
                Response.Write("<Script Language='JavaScript'>window.alert('创建失败！！');</script>");
            }
           
        }
    }
}