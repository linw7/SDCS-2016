﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.staff
{
    public partial class search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            //string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
            //string selectString = "SELECT id  FROM [user] WHERE mobile_num=@mobile_num";
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    connection.Open();
            //    SqlCommand command = new SqlCommand(selectString, connection);
            //    command.Parameters.AddWithValue("@mobile_num", mobile_num.Text);
            //    SqlDataReader reader = command.ExecuteReader();
            //    while (reader.Read())
            //    {
            //        if (reader.HasRows)
            //        {
            //            Session["user_id"] = reader["id"].ToString();
            //            Response.Redirect("~/staff/search_detail.aspx");
            //        }

            //        else
            //        {
            //            Response.Write("<Script Language='JavaScript'>window.alert('用户不存在！');</script>");
            //        }

            //    }
            //    Response.Write("<Script Language='JavaScript'>window.alert('用户不存在');</script>");
            //}

            try
            {
                using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
                {
                    var items = from item in context.User where item.mobile_num == mobile_num.Text.Trim() select item;
                    if (items.Count() > 0)
                    {
                        Session["user_id"] = items.Single().Id;
                        Response.Redirect("~/staff/search_detail.aspx");
                    }
                    else
                    {
                        Response.Write("<Script Language='JavaScript'>window.alert('用户不存在！');</script>");
                    }
                }
            }
            catch (Exception)
            {
                Response.Write("<Script Language='JavaScript'>window.alert('查找失败');</script>");
            }
        }
    }
}