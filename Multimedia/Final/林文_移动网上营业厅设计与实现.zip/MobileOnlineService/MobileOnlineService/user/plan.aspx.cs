﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.user
{
    public partial class plan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            //string delString = "DELETE  FROM [ServiceRecord] WHERE user_id=@user_id";
            //using (SqlConnection connection = new SqlConnection(delString))
            //{
            //    connection.Open();
            //    SqlCommand command = new SqlCommand(delString, connection);
            //    command.Parameters.AddWithValue("@user_id", Session["user_id"].ToString());
            //    int result = command.ExecuteNonQuery();
            //}
            //string basic_plan_num = basic_plan.SelectedValue;

            using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
            {
                //提交表单后，先清空原先所有的业务记录
                int user_id = Convert.ToInt32(Session["user_id"].ToString());
                var items = from item in context.ServiceRecord where item.user_id == user_id select item;
                foreach(var i in items){
                    context.ServiceRecord.Remove(i);
                    context.SaveChanges();
                }

                //提取套餐所含服务
                int plan_num = Convert.ToInt32(basic_plan.SelectedItem.Value);
                var plan_item = from item in context.BasicPlan where item.Id == plan_num select item;
                string strDescription = plan_item.Single().description;
                string[] service_nums = strDescription.Split('+');

                //新建套餐内业务记录
                foreach(string s in service_nums){
                    ServiceRecord sr = new ServiceRecord();
                    sr.service_id = Convert.ToInt32(s);
                    sr.user_id = Convert.ToInt32(Session["user_id"].ToString());
                    context.ServiceRecord.Add(sr);
                    context.SaveChanges();
                }

                //添加流量套餐记录
                int data_plan_num = Convert.ToInt32(data_plan.SelectedItem.Value);
                DataPlanRecord dpr = new DataPlanRecord();
                dpr.data_plan_id = data_plan_num;
                dpr.user_id = Convert.ToInt32(Session["user_id"].ToString());
                context.DataPlanRecord.Add(dpr);
                context.SaveChanges();

                //跳转
                Response.Redirect("~/user/plan_plus.aspx");

            }

            //using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
            //{
                
            //    var items = from item in context.User  select item;
            //    var singleItem = items.FirstOrDefault();
            //    submit.Text = singleItem.Id.ToString();

            //}

            //using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
            //{
            //    User user = new User();
            //    user.Id = 1;
            //    context.User.Add(user);
            //    context.SaveChanges();
            //}

        }
    }
}