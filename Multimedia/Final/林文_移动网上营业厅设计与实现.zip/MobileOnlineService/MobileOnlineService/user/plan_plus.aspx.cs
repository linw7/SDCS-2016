﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.user
{
    public partial class plan_plus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
            //{
            //    int user_id = Convert.ToInt32(Session["user_id"].ToString());
            //    var records = from record in context.ServiceRecord where record.user_id == user_id select record;
            //    foreach(var r in records){

            //        ListItem t = added_service.Items.FindByValue(r.service_id.ToString());
            //        added_service.Items.Remove(t);
            //    }

            //}
        }

        

        protected void submit_Click(object sender, EventArgs e)
        {
            using (MobileOnlineServiceEntities context = new MobileOnlineServiceEntities())
            {

                for (int i = 0; i < added_service.Items.Count; i++)
                {
                    if(added_service.Items[i].Selected){
                        int service_num = Convert.ToInt32(added_service.Items[i].Value);
                        ServiceRecord sr = new ServiceRecord();
                        sr.user_id = Convert.ToInt32(Session["user_id"].ToString());
                        sr.service_id = service_num;
                        context.ServiceRecord.Add(sr);
                        context.SaveChanges();
                    }
                }
               
                //跳转
                Response.Write("<Script Language='JavaScript'>window.alert('添加成功！');</script>");
                Response.Redirect("~/user/search.aspx");

            }
        }
    }
}