﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace MobileOnlineService.user
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != Session["cn"].ToString() || TextBox2.Text != Session["pwd"].ToString())
            {
                Response.Write("<script>alert('卡号或密码错误！')</script>");

            }
            else
            {
                string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
                string sql = string.Format("update [user] set balance=balance+{0}  where mobile_num='{1}'", Convert.ToDecimal(TextBox3.Text), TextBox4.Text);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    int n = cmd.ExecuteNonQuery();
                    if (n > 0)
                    {
                        Response.Write("<script>alert('充值成功！')</script>");
                    }

                }
            }
        }
    }
}