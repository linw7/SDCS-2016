﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


namespace MobileOnlineService.user
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
            string sq = string.Format("select price,vaild from [table] where card_num={0}",Convert.ToInt32(TextBox1.Text));
           

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sq, conn);
                SqlDataReader  dr = cmd.ExecuteReader();
                //int n = cmd.ExecuteNonQuery();
                if (!dr.Read() || Convert.ToInt32(dr["vaild"]) == 0)
                {
                    Response.Write("<script>alert('充值卡不可用！')</script>");
                }
                else 
                {
                    string sql = string.Format("update [user] set balance=balance+{0}  where mobile_num='{1}'", Convert.ToDecimal(dr["price"]), Session["loginname"]);
                    string s = string.Format("update [table] set vaild=0  where card_num='{0}'",  Convert.ToInt32(TextBox1.Text));
                   
                    SqlCommand cm = new SqlCommand(sql, conn);
                    SqlCommand c = new SqlCommand(s, conn);
                    int n = cm.ExecuteNonQuery();
                    int l = c.ExecuteNonQuery();
                    if (n > 0)
                    {
                        Response.Write("<script>alert('充值成功！')</script>");
                        
                    }

                
                }

            }
        }
    }
}