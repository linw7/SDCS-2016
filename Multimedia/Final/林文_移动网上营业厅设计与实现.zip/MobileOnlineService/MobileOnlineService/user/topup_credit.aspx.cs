﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace MobileOnlineService.user
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
                string sql = string.Format("select credit from [user]  where mobile_num='{0}'", Session["loginname"]);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    string credit = Convert.ToString(cmd.ExecuteScalar());
                    Label1.Text = credit;
                    
                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double credit = Convert.ToDouble(Label1.Text);
            if (credit < Convert.ToDouble(TextBox1.Text))
            {
                Response.Write("<script>alert('积分不够！')</script>");
            }
            else
            {
                string connectionString = ConfigurationManager.ConnectionStrings["MobileOnlineConnectionString"].ConnectionString;
                string sql = string.Format("update [user] set credit=credit-{0},balance=balance+{1}  where mobile_num='{2}'",Convert.ToInt32(TextBox1.Text),Convert.ToDecimal(TextBox1.Text),Session["loginname"]);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    int n = cmd.ExecuteNonQuery();
                    if (n > 0)
                    {
                        Response.Write("<script>alert('兑换成功！')</script>");
                    }

                }
            }
        }
    }
}