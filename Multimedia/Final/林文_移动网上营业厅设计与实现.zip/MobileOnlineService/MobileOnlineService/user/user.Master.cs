﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MobileOnlineService.user
{
    public partial class user : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["mobile_num"] != null)
            {
                login_name.Text = "欢迎 用户：" + Session["mobile_num"].ToString();
            }
            else
            {
                login_name.Text = "欢迎 匿名用户";
            }
        }
    }
}